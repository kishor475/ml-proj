# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: Apache-2.0

# DeepSpeed Team

import os
import re
from typing import Dict
import torch

from .reshape_3d_utils import model_3d_desc, get_model_3d_descriptor_from_metadata
from .reshape_utils import (basic_folder_validation, merge_state, partition_data, get_files, get_files_with_prefix,
                            get_zero_files)

from .constants import (MODEL_FILE_PREFIX, LAYER_FILE_PREFIX)

from .reshape_meg_2d import reshape_meg_2d_parallel, meg_2d_parallel_map
from .zero_checkpoint import ZeROCheckpoint
from .constants import *

EMBEDDING_LAYER_INDEX = 0
FINAL_LAYER_NORM_INDEX = -1
ARGS_KEY = 'args'
CHECKPOINT_INFO_KEY = 'checkpoint_info'
ITERATION_KEY = 'iteration'
LAYER_FILE_PREFIX_PATTERN = r'layer_(\d+)-model_.*'
USE_DATA_BEFORE_EXPERT_PARALLELISM = 'use_data_before_expert_parallelism'
AUTOEP_METADATA_FIELDS = ('moe_layer_id', 'module_path') + AUTOEP_ZERO12_REQUIRED_FIELDS

SEQUENTIAL_LAYERS = [
    'input_layernorm.weight', 'input_layernorm.bias', 'self_attention.dense.bias', 'post_attention_layernorm.weight',
    'post_attention_layernorm.bias', 'mlp.dense_4h_to_h.bias', 'position_embeddings.weight'
]

LAYER_CONCAT_DIM = {'self_attention.dense.weight': 1, 'mlp.dense_4h_to_h.weight': 1}


def _get_pipeline_layer_files(file_list):
    return sorted(
        [file_path for file_path in file_list if re.fullmatch(LAYER_FILE_PREFIX_PATTERN, os.path.basename(file_path))])


class DeepSpeedCheckpoint(object):

    def __init__(self,
                 dir,
                 tp_degree=None,
                 pp_degree=None,
                 dp_degree=None,
                 final_layer_norm_idx=FINAL_LAYER_NORM_INDEX):
        self.final_layer_norm_idx = final_layer_norm_idx
        self.dir = dir

        self.file_list = get_files(dir)
        self.layer_files = _get_pipeline_layer_files(self.file_list)
        pipeline_parallel = len(self.layer_files) > 0

        self._validate_folder(dir, pipeline_parallel)

        self.mp_rank_files = get_files_with_prefix(self.file_list, MODEL_FILE_PREFIX)
        self.model_state_metadata, self.global_state = self._discover_model_state_metadata()
        source_3d = get_model_3d_descriptor_from_metadata(self.file_list, get_zero_files(dir),
                                                          self.model_state_metadata)
        self.zero_checkpoint = ZeROCheckpoint(dir, source_3d=source_3d)

        self.layer_keys = self._get_layer_keys()
        self.layer_count = len(self.layer_keys)

        self.tp_degree = self.zero_checkpoint.get_src_tp_degree() if tp_degree is None else tp_degree
        self.pp_degree = self.zero_checkpoint.get_src_pp_degree() if pp_degree is None else pp_degree
        self.dp_degree = self.zero_checkpoint.get_src_dp_degree() if dp_degree is None else dp_degree

        self.original_world_size = self.zero_checkpoint.get_src_tp_degree() * self.zero_checkpoint.get_src_pp_degree(
        ) * self.zero_checkpoint.get_src_dp_degree()
        self.world_size = self.tp_degree * self.pp_degree * self.dp_degree

        self.old_2d_map = meg_2d_parallel_map(self.zero_checkpoint.get_src_pp_degree(),
                                              self.zero_checkpoint.get_src_tp_degree())
        self.old_2d_map.simple_init()
        self.new_2d_map = reshape_meg_2d_parallel(old_pp_degree=self.zero_checkpoint.get_src_pp_degree(),
                                                  old_tp_degree=self.zero_checkpoint.get_src_tp_degree(),
                                                  new_pp_degree=self.pp_degree,
                                                  new_tp_degree=self.tp_degree)

        if self.is_change_pp_degree() or self.is_change_tp_degree() or self.is_change_dp_degree():
            self.zero_checkpoint.reshape(model_3d_desc(self.pp_degree, self.tp_degree, self.dp_degree))

        self._sanity_check()
        self.pp_to_transformer_map = self._build_pp_transformer_map()
        self.transformer_file_map = self._build_transformer_file_map()
        self.tp_to_embedding_map = self._build_tp_other_layer_map(EMBEDDING_LAYER_INDEX)
        self.tp_to_final_norm_map = self._build_tp_other_layer_map(self.final_layer_norm_idx)

    @staticmethod
    def _lightweight_autoep_metadata(model_state):
        autoep_metadata = model_state.get(AUTOEP_LAYERS_KEY)
        if autoep_metadata is None:
            autoep_metadata = model_state.get(AUTOEP_LAYERS_KEY_LEGACY)
        if autoep_metadata is None or not isinstance(autoep_metadata, list):
            return autoep_metadata if autoep_metadata is None else type(autoep_metadata).__name__
        return [{
            key: entry[key]
            for key in AUTOEP_METADATA_FIELDS if key in entry
        } if isinstance(entry, dict) else type(entry).__name__ for entry in autoep_metadata]

    @staticmethod
    def _lightweight_ds_config(model_state):
        ds_config = model_state.get('ds_config', {})
        if not isinstance(ds_config, dict):
            return type(ds_config).__name__
        ordering = ds_config.get(USE_DATA_BEFORE_EXPERT_PARALLELISM, False)
        if not isinstance(ordering, bool):
            ordering = type(ordering).__name__
        return {USE_DATA_BEFORE_EXPERT_PARALLELISM: ordering}

    @staticmethod
    def _lightweight_param_shapes(model_state):
        param_shapes = model_state.get(PARAM_SHAPES)
        if not isinstance(param_shapes, (list, tuple)) or not all(isinstance(group, dict) for group in param_shapes):
            return None if param_shapes is None else type(param_shapes).__name__
        return {name: shape for group in param_shapes for name, shape in group.items()}

    @staticmethod
    def _lightweight_parallel_dimensions(model_state):
        dimensions = model_state.get(CHECKPOINT_PARALLEL_DIMS)
        if dimensions is None or not isinstance(dimensions, dict):
            return dimensions if dimensions is None else type(dimensions).__name__
        return {key: dimensions.get(key) for key in (CHECKPOINT_PP_DEGREE, CHECKPOINT_TP_DEGREE)}

    def _discover_model_state_metadata(self):
        """Load model-state files once and retain only descriptor/conversion metadata."""
        metadata_by_file = []
        global_state = {}
        known_global_keys = (ARGS_KEY, CHECKPOINT_INFO_KEY, UNIVERSAL_CHECKPOINT_INFO)
        for file_index, model_file in enumerate(self.mp_rank_files):
            model_state = torch.load(model_file, map_location=torch.device('cpu'), weights_only=False)
            metadata_by_file.append((model_file, {
                CHECKPOINT_PARALLEL_DIMS: self._lightweight_parallel_dimensions(model_state),
                PARAM_SHAPES: self._lightweight_param_shapes(model_state),
                AUTOEP_LAYERS_KEY: self._lightweight_autoep_metadata(model_state),
                'ds_config': self._lightweight_ds_config(model_state),
            }))
            if file_index == 0:
                global_state[ITERATION_KEY] = model_state.get(ITERATION_KEY, 0)
                for key in known_global_keys:
                    global_state[key] = model_state.get(key)
            del model_state
        return metadata_by_file, global_state

    def is_change_tp_degree(self):
        return self.tp_degree != self.zero_checkpoint.get_src_tp_degree()

    def is_change_pp_degree(self):
        return self.pp_degree != self.zero_checkpoint.get_src_pp_degree()

    def is_change_dp_degree(self):
        return self.dp_degree != self.zero_checkpoint.get_src_dp_degree()

    def show_2d_mapping(self):
        print('reshaped 2d map ---- begin')

        for i in range(self.pp_degree):
            for j in range(self.tp_degree):
                file_list = self.get_2d_parallel_files(pp_index=i, tp_index=j)
                print(f'[{i}, {j}] = {file_list}')

        print('reshaped 2d map ---- end')

    def show_tp_embedding_map(self):
        self._dump_mapping(self.tp_to_embedding_map, 'tp_to_embedding_layers')

    def show_tp_final_norm_map(self):
        self._dump_mapping(self.tp_to_final_norm_map, 'tp_to_final_norm_layers')

    def show_pp_transformer_map(self):
        self._dump_mapping(self.pp_to_transformer_map, 'pp_to_transformer_layers')

    def show_transformer_file_map(self):
        self._dump_mapping(self.transformer_file_map, 'rank_to_transformer_files')

    def get_zero_checkpoint_state(self, pp_index, tp_index, dp_index, strip_tensor_paddings: bool = True) -> dict:
        return self.zero_checkpoint.get_state_for_rank(pp_index=pp_index,
                                                       tp_index=tp_index,
                                                       dp_index=dp_index,
                                                       keys_to_ignore=[PARAM_SHAPES],
                                                       strip_tensor_paddings=strip_tensor_paddings)

    def get_zero_files(self, pp_index, tp_index, dp_index) -> list:
        return self.zero_checkpoint.get_files_for_rank(pp_index=pp_index, tp_index=tp_index, dp_index=dp_index)

    def get_embedding_layer_id(self):
        return self.layer_keys[EMBEDDING_LAYER_INDEX]

    def get_final_norm_layer_id(self):
        return self.layer_keys[self.final_layer_norm_idx]

    def get_iteration(self):
        if ITERATION_KEY not in self.global_state:
            sd = torch.load(self.mp_rank_files[0], map_location=torch.device('cpu'), weights_only=False)
            self.global_state[ITERATION_KEY] = sd.get(ITERATION_KEY, 0)

        return self.global_state[ITERATION_KEY]

    def get_embedding_state(self, tp_index: int) -> Dict:
        assert tp_index in self.tp_to_embedding_map.keys()
        sd_list = [
            torch.load(fname, map_location=torch.device('cpu'), weights_only=False)
            for fname in self.tp_to_embedding_map[tp_index]
        ]
        sd = self._merge_state_dicts(sd_list)
        return sd

    def get_embedding_files(self, tp_index: int) -> list:
        assert tp_index in self.tp_to_embedding_map.keys()
        return self.tp_to_embedding_map[tp_index]

    def _get_checkpoint_value(self, key):
        if key not in self.global_state:
            sd = torch.load(self.mp_rank_files[0], map_location=torch.device('cpu'), weights_only=False)
            self.global_state[key] = sd.get(key, None)

        return self.global_state[key]

    def get_args(self):
        return self._get_checkpoint_value(ARGS_KEY)

    def get_checkpoint_info(self, info_key=CHECKPOINT_INFO_KEY):
        return self._get_checkpoint_value(info_key)

    def get_2d_parallel_state(self, tp_index: int, pp_index: int) -> dict:
        assert tp_index < self.tp_degree
        assert pp_index < self.pp_degree
        fname_list = self.get_2d_parallel_files(tp_index=tp_index, pp_index=pp_index)
        sd_list = [torch.load(fname, map_location=torch.device('cpu'), weights_only=False) for fname in fname_list]

        merged_sd = None
        for sd in sd_list:
            if merged_sd is None:
                merged_sd = sd
            else:
                merged_sd = merge_state(merged_sd, sd)

        return merged_sd

    def get_transformer_state(self, tp_index: int, pp_index: int) -> list:
        assert tp_index < self.tp_degree
        assert pp_index < self.pp_degree
        t_list = []
        for fname_list in self.transformer_file_map[(tp_index, pp_index)]:
            sd_list = [torch.load(fname, map_location=torch.device('cpu'), weights_only=False) for fname in fname_list]
            sd = self._merge_state_dicts(sd_list)
            t_list.append(sd)
        return t_list

    def get_pp_transformer_map(self, pp_index: int) -> list:
        assert pp_index < self.pp_degree
        return self.pp_to_transformer_map[pp_index]

    def get_final_norm_state(self, tp_index: int) -> Dict:
        assert tp_index in self.tp_to_final_norm_map.keys()
        sd = torch.load(self.tp_to_final_norm_map[tp_index][0], map_location=torch.device('cpu'), weights_only=False)
        return sd

    def get_final_norm_files(self, tp_index: int) -> list:
        assert tp_index in self.tp_to_final_norm_map.keys()
        return self.tp_to_final_norm_map[tp_index]

    def _build_tp_other_layer_map(self, layer_index: int):
        data_map = {}
        if len(self.layer_files) < 1:
            return data_map
        assert layer_index <= len(self.layer_files)
        layer_files = get_files_with_prefix(self.layer_files, self.layer_keys[layer_index])
        layer_file_partitions = partition_data(layer_files, self.tp_degree)
        data_map = {i: flist for i, flist in enumerate(layer_file_partitions)}
        return data_map

    def get_2d_parallel_files(self, tp_index: int, pp_index: int) -> list:
        assert tp_index < self.tp_degree
        assert pp_index < self.pp_degree
        file_indices = self.new_2d_map.get_data(pp_index=pp_index, tp_index=tp_index)
        return [self.mp_rank_files[i] for i in file_indices]

    def _build_pp_transformer_map(self):
        data_map = {}
        if self.pp_degree > 0:
            transformer_layers = self.layer_keys[1:self.final_layer_norm_idx]
            layers_per_pp = len(transformer_layers) // self.pp_degree
            data_map = {
                i: transformer_layers[i * layers_per_pp:(i + 1) * layers_per_pp]
                for i in range(0, self.pp_degree)
            }
        return data_map

    def _dump_mapping(self, data_map, map_tag=None):
        if map_tag is not None:
            print(f'Dump mapping: {map_tag}')
        for k, v in data_map.items():
            print(f'{k} = {v}')

    def _build_transformer_file_map(self):
        transformer_layer_keys = self.layer_keys[1:self.final_layer_norm_idx]
        file_map = {}
        # XXX: this is not guaranteed
        layers_per_pp = 1
        if self.pp_degree > 0:
            layers_per_pp = len(transformer_layer_keys) // self.pp_degree
        #print(f"{transformer_layer_keys} {layers_per_pp}")
        for key_index, layer_key in enumerate(transformer_layer_keys):
            pp_index = key_index // layers_per_pp
            layer_files = get_files_with_prefix(self.layer_files, layer_key + '-')
            layer_file_partitions = partition_data(layer_files, self.tp_degree)
            for tp_index in range(self.tp_degree):
                map_key = (tp_index, pp_index)
                if map_key not in file_map.keys():
                    file_map[map_key] = []
                file_map[map_key].append(layer_file_partitions[tp_index])

        return file_map

    def _sanity_check(self):
        assert len(self.mp_rank_files) % self.tp_degree == 0
        assert self.zero_checkpoint.num_files % (self.pp_degree * self.tp_degree) == 0
        assert self.zero_checkpoint.num_files % (self.tp_degree) == 0
        # XXX: fix me - isn't always the case
        # only true with  --pp-partition-method 'type:transformer|embedding' \
        # assert (len(self.layer_keys) - 2) % self.pp_degree == 0

    def validate_files(self):
        for file in self.file_list:
            if not os.path.isfile(file):
                print(f'Error: {file} is not existent')

    def _get_layer_keys(self):
        key_set = set()
        for file_path in self.layer_files:
            _, fname = os.path.split(file_path)
            layer_id = re.search(LAYER_FILE_PREFIX_PATTERN, fname).group(1)
            key_set.add(layer_id)
        sorted_ids = sorted(list(key_set), key=int)
        layer_keys = [LAYER_FILE_PREFIX + str(layer_id) for layer_id in sorted_ids]
        return layer_keys

    def _merge_state_dicts(self, sd_list):
        merged_sd = {}
        for key in sd_list[0].keys():
            if key not in SEQUENTIAL_LAYERS:
                cat_dim = LAYER_CONCAT_DIM.get(key, 0)
                merged_sd[key] = torch.cat([sd[key] for sd in sd_list], dim=cat_dim)
            else:
                merged_sd[key] = sd_list[0][key]

        return merged_sd

    def _validate_folder(self, dir, pipeline_parallel):
        basic_folder_validation(dir)

        file_list = get_files(dir)
        file_prefix_list = [MODEL_FILE_PREFIX]
        if pipeline_parallel:
            file_prefix_list.extend([LAYER_FILE_PREFIX, f'{LAYER_FILE_PREFIX}01'])
        for file_prefix in file_prefix_list:
            ckpt_files = get_files_with_prefix(file_list, file_prefix)
            assert len(
                ckpt_files
            ) > 0, f'{dir} seems a bogus DeepSpeed checkpoint folder: Cannot find {file_prefix}* files in there.'
