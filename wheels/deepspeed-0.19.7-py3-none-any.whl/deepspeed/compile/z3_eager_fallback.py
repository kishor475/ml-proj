# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: Apache-2.0

# DeepSpeed Team

from contextlib import contextmanager
import sys

import torch

from deepspeed.runtime.zero.parameter_offload import ZeROOrderedDict, ensure_zero_ordered_dict
from deepspeed.runtime.zero.partition_parameters import (
    DS_Z3_EAGER_FALLBACK_OWNER_ATTR,
    DS_Z3_GATHERED_PARAM_CONTEXT_DEPTH_ATTR,
    ZeroParamStatus,
)

_ACTIVE_FALLBACK = None


def get_active_z3_eager_fallback():
    return _ACTIVE_FALLBACK


def record_z3_eager_fallback_param(param):
    fallback = get_active_z3_eager_fallback()
    if fallback is None:
        return False
    fallback.record_gathered_param(param)
    return True


def is_dynamo_guard_evaluation():
    """Return whether the current parameter access originates from Dynamo guard evaluation."""
    # This intentionally depends on private Dynamo stack layout. Real GuardBuilder source resolution was verified with
    # official CPU builds 2.8.0+cpu, 2.9.1+cpu, 2.10.0+cpu, 2.11.0+cpu, 2.12.0+cpu, and 2.13.0+cpu.
    frame = sys._getframe()
    while frame is not None:
        if frame.f_globals.get("__name__") == "torch._dynamo.guards":
            return True
        frame = frame.f_back
    return False


@contextmanager
def deepcompile_z3_forward_context(engine):
    fallback = getattr(engine, "_deepcompile_z3_eager_fallback", None)
    if fallback is None or not engine.is_deepcompile_active() or not engine.zero_optimization_partition_weights():
        yield None
        return

    with fallback.forward_context():
        yield fallback


class DeepCompileZ3EagerFallback:
    """Track eager-only ZeRO-3 gathers and restore partitioned state around compiled forwards."""

    def __init__(self, engine):
        self.engine = engine
        self._depth = 0
        self._tracked_params = {}
        self._last_gathered_param_ids = []
        self._last_released_param_ids = []
        self._last_guard_suppressed_param_ids = []
        self._last_pre_forward_released_param_ids = []
        self._last_user_adopted_param_ids = []
        self._user_adopted_param_ids = set()
        self._current_forward_param_ids = set()
        self._next_forward_graph_id = 0
        self._outstanding_forward_graph_ids = set()
        self._backward_started_forward_graph_ids = set()
        self._graph_claim_param_ids = {}
        self._param_graph_claim_ids = {}
        self._deferred_updated_param_ids = set()
        self._last_completed_forward_graph_ids = []
        self.total_gathered_params = 0

    @contextmanager
    def forward_context(self):
        """Enable fallback lookup for the outermost forward and restore nested state on exit."""
        global _ACTIVE_FALLBACK
        previous = _ACTIVE_FALLBACK
        self._depth += 1
        if self._depth == 1:
            self._last_gathered_param_ids.clear()
            self._last_guard_suppressed_param_ids.clear()
            self._last_pre_forward_released_param_ids.clear()
            self._current_forward_param_ids.clear()
            self.release_available_params_for_next_forward()
            self._enable_forward_fallback()
        _ACTIVE_FALLBACK = self
        try:
            yield
        finally:
            _ACTIVE_FALLBACK = previous
            self._depth -= 1
            if self._depth == 0:
                self._disable_forward_fallback()

    def _enable_forward_fallback(self):
        for module in self.engine.module.modules():
            ensure_zero_ordered_dict(module)
            module._parameters._in_forward = True

    def _disable_forward_fallback(self):
        for module in self.engine.module.modules():
            if isinstance(module._parameters, ZeROOrderedDict):
                module._parameters._in_forward = False

    def record_gathered_param(self, param):
        ds_id = param.ds_id
        previous_owner = getattr(param, DS_Z3_EAGER_FALLBACK_OWNER_ATTR, None)
        if previous_owner is not None and previous_owner is not self:
            previous_owner._drop_tracked_param(ds_id, param)
        self._tracked_params[ds_id] = param
        setattr(param, DS_Z3_EAGER_FALLBACK_OWNER_ATTR, self)
        self._current_forward_param_ids.add(ds_id)
        self._last_gathered_param_ids.append(ds_id)
        self.total_gathered_params += 1

    def record_param_access(self, param):
        """Associate an already-gathered fallback parameter with the current forward."""
        ds_id = param.ds_id
        if self._tracked_params.get(ds_id) is param:
            self._current_forward_param_ids.add(ds_id)

    def _drop_tracked_param(self, ds_id, param):
        if self._tracked_params.get(ds_id) is param:
            self._tracked_params.pop(ds_id)
        self._current_forward_param_ids.discard(ds_id)
        for graph_id in self._param_graph_claim_ids.pop(ds_id, set()):
            self._graph_claim_param_ids.get(graph_id, set()).discard(ds_id)
        self._deferred_updated_param_ids.discard(ds_id)
        if getattr(param, DS_Z3_EAGER_FALLBACK_OWNER_ATTR, None) is self:
            delattr(param, DS_Z3_EAGER_FALLBACK_OWNER_ATTR)

    def record_user_context_claim(self, param):
        """Record that an explicit user context overlaps this fallback-owned parameter."""
        ds_id = param.ds_id
        if ds_id not in self._user_adopted_param_ids:
            self._user_adopted_param_ids.add(ds_id)
            self._last_user_adopted_param_ids.append(ds_id)

    def release_user_context_claim(self, param):
        """Drop fallback provenance once neither a graph nor user context protects the parameter."""
        ds_id = param.ds_id
        if (not self._param_graph_claim_ids.get(ds_id)
                and not getattr(param, DS_Z3_GATHERED_PARAM_CONTEXT_DEPTH_ATTR, 0)):
            self._drop_tracked_param(ds_id, param)

    def has_outstanding_graph_claim(self, param):
        return bool(self._param_graph_claim_ids.get(param.ds_id))

    def record_deferred_user_update(self, param):
        """Preserve modifier-rank update provenance until the graph claim releases."""
        self._deferred_updated_param_ids.add(param.ds_id)

    def record_guard_suppressed_param(self, param):
        """Record a guard probe that intentionally observed the partitioned parameter."""
        self._last_guard_suppressed_param_ids.append(param.ds_id)

    def record_forward_graph(self):
        """Record a grad-bearing forward whose fallback gathers must survive until backward."""
        graph_id = self._next_forward_graph_id
        self._next_forward_graph_id += 1
        self._outstanding_forward_graph_ids.add(graph_id)
        param_ids = set(self._current_forward_param_ids)
        self._graph_claim_param_ids[graph_id] = param_ids
        for ds_id in param_ids:
            self._param_graph_claim_ids.setdefault(ds_id, set()).add(graph_id)
        return graph_id

    def record_backward_start(self, graph_id):
        """Record that backward reached an output from a tracked forward graph."""
        if graph_id in self._outstanding_forward_graph_ids:
            self._backward_started_forward_graph_ids.add(graph_id)

    @torch.no_grad()
    def release_available_params_for_next_forward(self):
        """Restore the partitioned parameter state expected by Dynamo guards."""
        released = self._release_unclaimed_tracked_params()

        if not self._outstanding_forward_graph_ids and self.engine is not None:
            for param in self.engine.module.parameters():
                if (hasattr(param, "ds_status") and param.ds_status == ZeroParamStatus.AVAILABLE
                        and not getattr(param, "ds_persist", False)
                        and not getattr(param, DS_Z3_GATHERED_PARAM_CONTEXT_DEPTH_ATTR, 0)):
                    param.partition()
                    released.append(param.ds_id)

        self._last_pre_forward_released_param_ids = released

    @torch.no_grad()
    def _release_unclaimed_tracked_params(self):
        released = []
        for ds_id, param in list(self._tracked_params.items()):
            if (self._param_graph_claim_ids.get(ds_id) or getattr(param, DS_Z3_GATHERED_PARAM_CONTEXT_DEPTH_ATTR, 0)):
                continue
            if (hasattr(param, "ds_status") and param.ds_status == ZeroParamStatus.AVAILABLE
                    and not getattr(param, "ds_persist", False)):
                if ds_id in self._deferred_updated_param_ids:
                    param.partition(has_been_updated=True)
                else:
                    param.partition()
                released.append(ds_id)
            self._drop_tracked_param(ds_id, param)
        return released

    @torch.no_grad()
    def _release_gathered_params(self):
        released = self._release_unclaimed_tracked_params()
        self._last_released_param_ids = released

    def complete_backward(self):
        """Release each fallback gather after its last reached forward graph completes."""
        completed = sorted(self._backward_started_forward_graph_ids)
        if not completed:
            return

        self._backward_started_forward_graph_ids.clear()
        self._outstanding_forward_graph_ids.difference_update(completed)
        for graph_id in completed:
            for ds_id in self._graph_claim_param_ids.pop(graph_id, set()):
                claims = self._param_graph_claim_ids.get(ds_id)
                if claims is None:
                    continue
                claims.discard(graph_id)
                if not claims:
                    self._param_graph_claim_ids.pop(ds_id)
        self._last_completed_forward_graph_ids = completed
        self._release_gathered_params()

    def release_gathered_params(self):
        """Explicitly release gathers when pending backward work is intentionally abandoned."""
        self._outstanding_forward_graph_ids.clear()
        self._backward_started_forward_graph_ids.clear()
        self._graph_claim_param_ids.clear()
        self._param_graph_claim_ids.clear()
        self._release_gathered_params()

    def stats(self):
        return {
            "tracked_param_ids":
            sorted(self._tracked_params),
            "last_gathered_param_ids":
            list(self._last_gathered_param_ids),
            "last_released_param_ids":
            list(self._last_released_param_ids),
            "last_guard_suppressed_param_ids":
            list(self._last_guard_suppressed_param_ids),
            "last_pre_forward_released_param_ids":
            list(self._last_pre_forward_released_param_ids),
            "last_user_adopted_param_ids":
            list(self._last_user_adopted_param_ids),
            "current_forward_param_ids":
            sorted(self._current_forward_param_ids),
            "outstanding_forward_graph_ids":
            sorted(self._outstanding_forward_graph_ids),
            "backward_started_forward_graph_ids":
            sorted(self._backward_started_forward_graph_ids),
            "graph_claim_param_ids": {
                graph_id: sorted(param_ids)
                for graph_id, param_ids in sorted(self._graph_claim_param_ids.items())
            },
            "param_graph_claim_ids": {
                ds_id: sorted(graph_ids)
                for ds_id, graph_ids in sorted(self._param_graph_claim_ids.items())
            },
            "context_claimed_param_ids":
            sorted(ds_id for ds_id, param in self._tracked_params.items()
                   if getattr(param, DS_Z3_GATHERED_PARAM_CONTEXT_DEPTH_ATTR, 0)),
            "deferred_updated_param_ids":
            sorted(self._deferred_updated_param_ids),
            "last_completed_forward_graph_ids":
            list(self._last_completed_forward_graph_ids),
            "total_gathered_params":
            self.total_gathered_params,
        }
